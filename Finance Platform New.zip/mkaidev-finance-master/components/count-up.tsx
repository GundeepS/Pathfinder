"use client";

import CountUp from "react-countup";

export default CountUp;
